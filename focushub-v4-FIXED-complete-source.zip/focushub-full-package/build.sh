#!/bin/bash
# FocusHub Build Script
# This script builds the React app and properly organizes all files for deployment

echo "🔨 Building React app..."
npm run build

echo "📦 Organizing files..."
# Rename the React app from index.html to app.html
mv dist/index.html dist/app.html

# Copy marketing pages
echo "📄 Copying marketing pages..."
cp public-pages/index.html dist/
cp public-pages/home.html dist/
cp public-pages/faq.html dist/
cp public-pages/how-to.html dist/
cp public-pages/*.jpg dist/ 2>/dev/null || true

echo "✅ Build complete!"
echo ""
echo "📂 Files ready in dist/:"
ls -lh dist/*.html

echo ""
echo "🚀 Ready to deploy!"
echo "   - React app: /app.html"
echo "   - Landing page: /index.html"
echo "   - FAQ + Support: /faq.html"
echo "   - How-To Guide: /how-to.html"
