export const initializeFirebase = () => {
  console.log('Firebase initialized (stub)');
};
